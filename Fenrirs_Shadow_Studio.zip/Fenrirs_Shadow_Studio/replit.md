# Fenrir's Shadow Studio

## Overview

Fenrir's Shadow Studio is a comprehensive Android IDE designed to run entirely on Android devices, specifically optimized for Android 16 (API 36). The project aims to provide a full-featured development environment for Android app development directly on mobile devices, including code editing, project management, building, debugging, and visual design tools.

## Current Status (Phase 1 - Foundation MVP)

**Implementation Date**: November 5, 2025  
**Status**: Phase 1 Complete - UI architecture implemented with 28 files and 4,569 lines of Kotlin code

### Completed Components
- ✅ Advanced rope-based text editor with O(log n) operations
- ✅ Multi-language syntax highlighting (Kotlin, Java, XML, JSON)
- ✅ Tabbed editor interface with file management
- ✅ Project file tree with hierarchical navigation
- ✅ Build pane with Gradle integration UI
- ✅ Device management pane with ADB integration UI
- ✅ Debugging tools UI (breakpoints, variables, call stack)
- ✅ Visual XML design pane with device preview
- ✅ ConstraintLayout visual editor with drag-and-drop
- ✅ Resource resolver for Android resources
- ✅ Code quality system (Witness/Verify) with lint checks
- ✅ Status bar and navigation rail
- ✅ Material Design 3 theming with dark/light modes

### Known Limitations
Several core features require additional backend services to function on-device:
- Build system needs remote build server (no on-device Gradle/JDK)
- Device management needs network-based solution (no on-device ADB)
- Debugging needs JDWP backend implementation
- File access needs SAF migration for API 33+ compliance

### Next Steps (Phase 2)
- Remote build server integration
- Storage Access Framework (SAF) implementation
- Real debugging backend with JDWP
- Advanced code intelligence features
- Git integration via JGit

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Editor Architecture
- **Rope Data Structure**: The code editor uses a rope-based text representation to achieve O(log n) performance for text operations on large files. This architectural decision prioritizes efficient handling of large codebases over simpler string-based implementations.
- **Real-time Syntax Highlighting**: Multi-language support (Kotlin, Java, XML, JSON) with real-time parsing and highlighting.
- **Advanced Editing Features**: Multi-cursor editing, code folding, unlimited undo/redo history, line numbers, and minimap visualization.

### Project Management
- **Multi-project Workspace**: Supports managing multiple Android projects simultaneously with hierarchical file tree navigation.
- **File System Integration**: Manages recent files, favorites, and file templates for rapid project scaffolding.

### Build System
- **Gradle Integration**: Full support for Gradle wrapper, enabling builds directly on the Android device.
- **Incremental Build Support**: Optimizes build times by only rebuilding changed components.
- **Build Output Parser**: Processes build errors and warnings with clickable navigation to source code.
- **APK Analysis**: Built-in tools for analyzing generated APK files.

### Device & Testing Infrastructure
- **ADB Integration**: Direct Android Debug Bridge integration for device detection and management.
- **Wireless Debugging**: Support for wireless ADB connections (Android 11+).
- **Logcat Viewer**: Real-time log viewing with filtering capabilities.
- **One-tap Deploy**: Streamlined installation and execution workflow.

### Debugging System
- **Breakpoint Management**: Full breakpoint support for debugging Android applications.
- **Runtime Inspection**: Variable inspection and call stack navigation during debugging sessions.
- **Step Controls**: Standard debugging controls (step over, step into, step out, continue).

### Visual Design Tools
- **Live XML Preview**: Real-time rendering of XML layouts as they are edited.
- **ConstraintLayout Visual Editor**: Graphical editor for designing ConstraintLayout-based UIs.
- **Component Palette**: Drag-and-drop UI component library.
- **Resource Manager**: Centralized management of app resources (drawables, strings, colors, dimensions).
- **Theme Editor**: Visual editor for creating and modifying Material Design themes.

## External Dependencies

### Build Tools & SDK
- **Android SDK**: Required for compilation and building Android applications
- **Gradle**: Build automation system (via Gradle wrapper)
- **Android Build Tools**: Compilation and packaging tools

### Device Communication
- **ADB (Android Debug Bridge)**: For device detection, app installation, and debugging communication
- **Wireless ADB Protocol**: For cable-free device connection (Android 11+)

### Runtime & APIs
- **Android 16 (API 36)**: Target platform for the IDE itself
- **Java/Kotlin Compilers**: For compiling Android application source code

### Potential Additional Dependencies
- **XML Parsers**: For layout file processing and validation
- **JSON Libraries**: For configuration file handling
- **Syntax Highlighting Libraries**: For code editor language support