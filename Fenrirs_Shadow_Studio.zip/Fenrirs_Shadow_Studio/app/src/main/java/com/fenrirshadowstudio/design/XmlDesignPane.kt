package com.fenrirshadowstudio.design

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun XmlDesignPane(
    xmlContent: String,
    onXmlChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showPreview by remember { mutableStateOf(true) }
    var selectedDevice by remember { mutableStateOf("Phone") }
    var orientation by remember { mutableStateOf("Portrait") }
    
    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("XML Design") },
            actions = {
                IconButton(onClick = { showPreview = !showPreview }) {
                    Icon(
                        imageVector = if (showPreview) Icons.Default.Code else Icons.Default.Visibility,
                        contentDescription = "Toggle Preview"
                    )
                }
            }
        )
        
        DesignToolbar(
            selectedDevice = selectedDevice,
            orientation = orientation,
            onDeviceChanged = { selectedDevice = it },
            onOrientationChanged = { orientation = it },
            modifier = Modifier.fillMaxWidth()
        )
        
        if (showPreview) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                PreviewPane(
                    xmlContent = xmlContent,
                    device = selectedDevice,
                    orientation = orientation,
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                )
                
                Divider(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.dp)
                )
                
                AttributePanel(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(300.dp)
                )
            }
        } else {
            XmlEditor(
                content = xmlContent,
                onContentChange = onXmlChanged,
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
        }
    }
}

@Composable
private fun DesignToolbar(
    selectedDevice: String,
    orientation: String,
    onDeviceChanged: (String) -> Unit,
    onOrientationChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            var deviceExpanded by remember { mutableStateOf(false) }
            
            ExposedDropdownMenuBox(
                expanded = deviceExpanded,
                onExpandedChange = { deviceExpanded = it }
            ) {
                OutlinedButton(
                    onClick = { deviceExpanded = true },
                    modifier = Modifier.menuAnchor()
                ) {
                    Icon(Icons.Default.Smartphone, null)
                    Spacer(Modifier.width(8.dp))
                    Text(selectedDevice)
                }
                
                ExposedDropdownMenu(
                    expanded = deviceExpanded,
                    onDismissRequest = { deviceExpanded = false }
                ) {
                    listOf("Phone", "Tablet", "Foldable", "Wear OS", "TV").forEach { device ->
                        DropdownMenuItem(
                            text = { Text(device) },
                            onClick = {
                                onDeviceChanged(device)
                                deviceExpanded = false
                            }
                        )
                    }
                }
            }
            
            IconButton(
                onClick = {
                    onOrientationChanged(if (orientation == "Portrait") "Landscape" else "Portrait")
                }
            ) {
                Icon(
                    imageVector = if (orientation == "Portrait") {
                        Icons.Default.PhoneAndroid
                    } else {
                        Icons.Default.Tablet
                    },
                    contentDescription = "Toggle Orientation"
                )
            }
            
            Text(
                text = orientation,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun PreviewPane(
    xmlContent: String,
    device: String,
    orientation: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFF37474F))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        val deviceSize = when (device) {
            "Phone" -> if (orientation == "Portrait") 360.dp to 640.dp else 640.dp to 360.dp
            "Tablet" -> if (orientation == "Portrait") 600.dp to 960.dp else 960.dp to 600.dp
            "Foldable" -> if (orientation == "Portrait") 420.dp to 840.dp else 840.dp to 420.dp
            "Wear OS" -> 384.dp to 384.dp
            "TV" -> 1280.dp to 720.dp
            else -> 360.dp to 640.dp
        }
        
        Surface(
            modifier = Modifier
                .size(deviceSize.first, deviceSize.second)
                .border(2.dp, MaterialTheme.colorScheme.outline),
            color = MaterialTheme.colorScheme.surface
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Layout Preview\n\n${device}\n${orientation}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
    }
}

@Composable
private fun AttributePanel(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Attributes",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            AttributeSection(title = "Layout") {
                AttributeField("Width", "match_parent")
                AttributeField("Height", "wrap_content")
                AttributeField("Margin", "16dp")
                AttributeField("Padding", "8dp")
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            AttributeSection(title = "Common") {
                AttributeField("ID", "@+id/my_view")
                AttributeField("Background", "@color/white")
                AttributeField("Visibility", "visible")
            }
        }
    }
}

@Composable
private fun AttributeSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        content()
    }
}

@Composable
private fun AttributeField(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f)
        )
        
        OutlinedTextField(
            value = value,
            onValueChange = {},
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            modifier = Modifier.weight(2f),
            singleLine = true
        )
    }
}

@Composable
private fun XmlEditor(
    content: String,
    onContentChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    
    Box(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface)
            .verticalScroll(scrollState)
            .horizontalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = content,
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
