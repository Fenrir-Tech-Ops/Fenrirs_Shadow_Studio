package com.fenrirshadowstudio.witness

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VerifyPane(
    projectRoot: File?,
    onFileNavigate: (String, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var issues by remember { mutableStateOf(listOf<CodeIssue>()) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var filterSeverity by remember { mutableStateOf<IssueSeverity?>(null) }
    var filterType by remember { mutableStateOf<IssueType?>(null) }
    val scope = rememberCoroutineScope()
    val witness = remember { Witness() }
    
    val filteredIssues = remember(issues, filterSeverity, filterType) {
        issues.filter { issue ->
            (filterSeverity == null || issue.severity == filterSeverity) &&
            (filterType == null || issue.type == filterType)
        }
    }
    
    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Code Quality") },
            actions = {
                IconButton(
                    onClick = {
                        scope.launch {
                            isAnalyzing = true
                            issues = analyzeProject(projectRoot, witness)
                            isAnalyzing = false
                        }
                    },
                    enabled = !isAnalyzing && projectRoot != null
                ) {
                    Icon(
                        imageVector = if (isAnalyzing) Icons.Default.Sync else Icons.Default.PlayArrow,
                        contentDescription = "Analyze"
                    )
                }
                
                IconButton(onClick = { issues = emptyList() }) {
                    Icon(Icons.Default.Clear, "Clear")
                }
            }
        )
        
        if (isAnalyzing) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
        
        IssuesSummary(
            issues = issues,
            filterSeverity = filterSeverity,
            filterType = filterType,
            onSeverityFilterChanged = { filterSeverity = it },
            onTypeFilterChanged = { filterType = it },
            modifier = Modifier.fillMaxWidth()
        )
        
        if (filteredIssues.isEmpty() && issues.isNotEmpty()) {
            EmptyFilteredView(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
        } else if (filteredIssues.isEmpty()) {
            EmptyIssuesView(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(8.dp)
            ) {
                items(filteredIssues) { issue ->
                    IssueItem(
                        issue = issue,
                        onClick = { onFileNavigate(issue.file, issue.line) }
                    )
                }
            }
        }
    }
}

@Composable
private fun IssuesSummary(
    issues: List<CodeIssue>,
    filterSeverity: IssueSeverity?,
    filterType: IssueType?,
    onSeverityFilterChanged: (IssueSeverity?) -> Unit,
    onTypeFilterChanged: (IssueType?) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                IssueSummaryChip(
                    count = issues.count { it.severity == IssueSeverity.ERROR },
                    label = "Errors",
                    color = MaterialTheme.colorScheme.error,
                    isSelected = filterSeverity == IssueSeverity.ERROR,
                    onClick = {
                        onSeverityFilterChanged(
                            if (filterSeverity == IssueSeverity.ERROR) null else IssueSeverity.ERROR
                        )
                    }
                )
                
                IssueSummaryChip(
                    count = issues.count { it.severity == IssueSeverity.WARNING },
                    label = "Warnings",
                    color = Color(0xFFFFA726),
                    isSelected = filterSeverity == IssueSeverity.WARNING,
                    onClick = {
                        onSeverityFilterChanged(
                            if (filterSeverity == IssueSeverity.WARNING) null else IssueSeverity.WARNING
                        )
                    }
                )
                
                IssueSummaryChip(
                    count = issues.count { it.severity == IssueSeverity.INFO },
                    label = "Info",
                    color = MaterialTheme.colorScheme.primary,
                    isSelected = filterSeverity == IssueSeverity.INFO,
                    onClick = {
                        onSeverityFilterChanged(
                            if (filterSeverity == IssueSeverity.INFO) null else IssueSeverity.INFO
                        )
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IssueType.entries.forEach { type ->
                    val count = issues.count { it.type == type }
                    if (count > 0) {
                        FilterChip(
                            selected = filterType == type,
                            onClick = {
                                onTypeFilterChanged(if (filterType == type) null else type)
                            },
                            label = { Text("${type.name} ($count)") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IssueSummaryChip(
    count: Int,
    label: String,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = if (isSelected) color.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.medium,
        border = if (isSelected) BorderStroke(2.dp, color) else null
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.titleLarge,
                color = color
            )
            
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun IssueItem(
    issue: CodeIssue,
    onClick: () -> Unit
) {
    val backgroundColor = when (issue.severity) {
        IssueSeverity.ERROR -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
        IssueSeverity.WARNING -> Color(0xFFFFF3E0)
        IssueSeverity.INFO -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
        IssueSeverity.HINT -> Color.Transparent
    }
    
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clickable(onClick = onClick),
        color = backgroundColor,
        shape = MaterialTheme.shapes.small
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = when (issue.severity) {
                    IssueSeverity.ERROR -> Icons.Default.Error
                    IssueSeverity.WARNING -> Icons.Default.Warning
                    IssueSeverity.INFO -> Icons.Default.Info
                    IssueSeverity.HINT -> Icons.Default.Lightbulb
                },
                contentDescription = null,
                tint = when (issue.severity) {
                    IssueSeverity.ERROR -> MaterialTheme.colorScheme.error
                    IssueSeverity.WARNING -> Color(0xFFFFA726)
                    IssueSeverity.INFO -> MaterialTheme.colorScheme.primary
                    IssueSeverity.HINT -> Color(0xFF9E9E9E)
                },
                modifier = Modifier.size(20.dp)
            )
            
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Badge(
                        containerColor = when (issue.severity) {
                            IssueSeverity.ERROR -> MaterialTheme.colorScheme.error
                            IssueSeverity.WARNING -> Color(0xFFFFA726)
                            IssueSeverity.INFO -> MaterialTheme.colorScheme.primary
                            IssueSeverity.HINT -> Color(0xFF9E9E9E)
                        }
                    ) {
                        Text(
                            text = issue.severity.name,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    
                    Badge(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                        Text(
                            text = issue.type.name,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = issue.message,
                    style = MaterialTheme.typography.bodyMedium
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = "${File(issue.file).name}:${issue.line}:${issue.column}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontFamily = FontFamily.Monospace
                )
                
                if (issue.suggestion != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(
                            Icons.Default.Lightbulb,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = Color(0xFFFFC107)
                        )
                        
                        Text(
                            text = issue.suggestion,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyIssuesView(modifier: Modifier = Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = Color(0xFF4CAF50)
            )
            
            Text(
                text = "No issues found",
                style = MaterialTheme.typography.titleMedium
            )
            
            Text(
                text = "Run analysis to check your code",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
private fun EmptyFilteredView(modifier: Modifier = Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Text(
            text = "No issues match the current filters",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
    }
}

private suspend fun analyzeProject(projectRoot: File?, witness: Witness): List<CodeIssue> = 
    withContext(Dispatchers.IO) {
        if (projectRoot == null) return@withContext emptyList()
        
        val issues = mutableListOf<CodeIssue>()
        
        fun analyzeDirectory(dir: File) {
            dir.listFiles()?.forEach { file ->
                when {
                    file.isDirectory && !file.name.startsWith(".") && file.name != "build" -> {
                        analyzeDirectory(file)
                    }
                    file.extension == "kt" -> {
                        issues.addAll(witness.analyzeKotlinFile(file, file.readText()))
                    }
                    file.extension == "xml" && file.parentFile?.name?.startsWith("layout") == true -> {
                        issues.addAll(witness.analyzeXmlFile(file, file.readText()))
                    }
                }
            }
        }
        
        val srcDir = File(projectRoot, "app/src/main")
        if (srcDir.exists()) {
            analyzeDirectory(srcDir)
        }
        
        issues
    }
