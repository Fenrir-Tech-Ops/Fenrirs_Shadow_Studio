package com.fenrirshadowstudio.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.io.File

data class EditorTab(
    val id: String,
    val filePath: String,
    val fileName: String,
    val language: String,
    val viewModel: EditorViewModel
)

@Composable
fun TabbedEditorPane(
    modifier: Modifier = Modifier
) {
    var tabs by remember { mutableStateOf(listOf<EditorTab>()) }
    var activeTabId by remember { mutableStateOf<String?>(null) }
    
    Column(modifier = modifier.fillMaxSize()) {
        if (tabs.isNotEmpty()) {
            TabBar(
                tabs = tabs,
                activeTabId = activeTabId,
                onTabSelected = { tabId -> activeTabId = tabId },
                onTabClosed = { tabId ->
                    tabs = tabs.filterNot { it.id == tabId }
                    if (activeTabId == tabId) {
                        activeTabId = tabs.firstOrNull()?.id
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
        
        val activeTab = tabs.find { it.id == activeTabId }
        
        if (activeTab != null) {
            val editorState by activeTab.viewModel.state
            
            CodeEditor(
                initialContent = editorState.content.toString(),
                language = activeTab.language,
                onContentChange = { content ->
                },
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
            
            EditorStatusBar(
                filePath = activeTab.filePath,
                isDirty = editorState.isDirty,
                line = calculateLine(editorState.content, editorState.cursorPosition),
                column = calculateColumn(editorState.content, editorState.cursorPosition),
                language = activeTab.language
            )
        } else {
            WelcomeScreen(
                onNewFile = {
                    tabs = tabs + createNewTab("Untitled.kt", "kotlin", "")
                    activeTabId = tabs.last().id
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun TabBar(
    tabs: List<EditorTab>,
    activeTabId: String?,
    onTabSelected: (String) -> Unit,
    onTabClosed: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 2.dp
    ) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.Start
        ) {
            items(tabs, key = { it.id }) { tab ->
                EditorTab(
                    tab = tab,
                    isActive = tab.id == activeTabId,
                    onClick = { onTabSelected(tab.id) },
                    onClose = { onTabClosed(tab.id) }
                )
            }
        }
    }
}

@Composable
private fun EditorTab(
    tab: EditorTab,
    isActive: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    val editorState by tab.viewModel.state
    
    Surface(
        modifier = Modifier
            .height(48.dp)
            .clickable(onClick = onClick),
        color = if (isActive) {
            MaterialTheme.colorScheme.surfaceVariant
        } else {
            MaterialTheme.colorScheme.surface
        }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (editorState.isDirty) "● ${tab.fileName}" else tab.fileName,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 150.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(20.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun EditorStatusBar(
    filePath: String,
    isDirty: Boolean,
    line: Int,
    column: Int,
    language: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isDirty) "● $filePath" else filePath,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                    text = "Ln $line, Col $column",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                
                Text(
                    text = language.uppercase(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun WelcomeScreen(
    onNewFile: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Text(
                text = "Fenrir's Shadow Studio",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary
            )
            
            Text(
                text = "God-Tier Android IDE",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Button(onClick = onNewFile) {
                Text("New File")
            }
        }
    }
}

private fun createNewTab(
    fileName: String,
    language: String,
    content: String
): EditorTab {
    val viewModel = EditorViewModel()
    viewModel.loadFile(content, fileName, language)
    
    return EditorTab(
        id = System.currentTimeMillis().toString(),
        filePath = fileName,
        fileName = File(fileName).name,
        language = language,
        viewModel = viewModel
    )
}

private fun calculateLine(rope: Rope, position: Int): Int {
    var line = 1
    for (i in 0 until position.coerceAtMost(rope.length)) {
        if (rope.charAt(i) == '\n') line++
    }
    return line
}

private fun calculateColumn(rope: Rope, position: Int): Int {
    var column = 1
    for (i in (position - 1) downTo 0) {
        if (rope.charAt(i) == '\n') break
        column++
    }
    return column
}

fun detectLanguage(fileName: String): String {
    return when (File(fileName).extension.lowercase()) {
        "kt" -> "kotlin"
        "java" -> "java"
        "xml" -> "xml"
        "json" -> "json"
        "gradle", "kts" -> "kotlin"
        "properties" -> "properties"
        else -> "text"
    }
}
