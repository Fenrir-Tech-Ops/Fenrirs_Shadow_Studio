package com.fenrirshadowstudio.device

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

data class AndroidDevice(
    val id: String,
    val model: String,
    val androidVersion: String,
    val status: DeviceStatus
)

enum class DeviceStatus {
    ONLINE, OFFLINE, UNAUTHORIZED
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevicePane(
    onDeviceSelected: (AndroidDevice) -> Unit,
    onInstallApk: (AndroidDevice, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var devices by remember { mutableStateOf(listOf<AndroidDevice>()) }
    var selectedDevice by remember { mutableStateOf<AndroidDevice?>(null) }
    var isRefreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    
    LaunchedEffect(Unit) {
        while (true) {
            devices = detectDevices()
            delay(3000)
        }
    }
    
    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Devices") },
            actions = {
                IconButton(
                    onClick = {
                        scope.launch {
                            isRefreshing = true
                            devices = detectDevices()
                            isRefreshing = false
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (isRefreshing) Icons.Default.Sync else Icons.Default.Refresh,
                        contentDescription = "Refresh"
                    )
                }
            }
        )
        
        if (devices.isEmpty()) {
            EmptyDeviceView(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(8.dp)
            ) {
                items(devices) { device ->
                    DeviceItem(
                        device = device,
                        isSelected = selectedDevice == device,
                        onClick = {
                            selectedDevice = device
                            onDeviceSelected(device)
                        }
                    )
                }
            }
        }
        
        selectedDevice?.let { device ->
            DeviceActions(
                device = device,
                onInstall = { apkPath ->
                    onInstallApk(device, apkPath)
                },
                onUninstall = {
                },
                onClearData = {
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun DeviceItem(
    device: AndroidDevice,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onClick),
        color = if (isSelected) {
            MaterialTheme.colorScheme.secondaryContainer
        } else {
            MaterialTheme.colorScheme.surface
        },
        tonalElevation = if (isSelected) 4.dp else 1.dp,
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Smartphone,
                contentDescription = null,
                tint = when (device.status) {
                    DeviceStatus.ONLINE -> MaterialTheme.colorScheme.primary
                    DeviceStatus.OFFLINE -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    DeviceStatus.UNAUTHORIZED -> MaterialTheme.colorScheme.error
                },
                modifier = Modifier.size(32.dp)
            )
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = device.model,
                    style = MaterialTheme.typography.titleMedium
                )
                
                Text(
                    text = "Android ${device.androidVersion} • ${device.id}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            
            Badge(
                containerColor = when (device.status) {
                    DeviceStatus.ONLINE -> MaterialTheme.colorScheme.primaryContainer
                    DeviceStatus.OFFLINE -> MaterialTheme.colorScheme.surfaceVariant
                    DeviceStatus.UNAUTHORIZED -> MaterialTheme.colorScheme.errorContainer
                }
            ) {
                Text(
                    text = device.status.name,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun EmptyDeviceView(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PhoneAndroid,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
            )
            
            Text(
                text = "No devices detected",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            
            Text(
                text = "Connect a device via USB or enable wireless debugging",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun DeviceActions(
    device: AndroidDevice,
    onInstall: (String) -> Unit,
    onUninstall: () -> Unit,
    onClearData: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { },
                enabled = device.status == DeviceStatus.ONLINE
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Run")
            }
            
            OutlinedButton(
                onClick = onUninstall,
                enabled = device.status == DeviceStatus.ONLINE
            ) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Uninstall")
            }
            
            OutlinedButton(
                onClick = onClearData,
                enabled = device.status == DeviceStatus.ONLINE
            ) {
                Icon(Icons.Default.CleaningServices, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Clear Data")
            }
        }
    }
}

private suspend fun detectDevices(): List<AndroidDevice> = withContext(Dispatchers.IO) {
    val devices = mutableListOf<AndroidDevice>()
    
    try {
        val process = ProcessBuilder()
            .command("adb", "devices", "-l")
            .redirectErrorStream(true)
            .start()
        
        val reader = BufferedReader(InputStreamReader(process.inputStream))
        reader.readLine()
        
        var line: String?
        while (reader.readLine().also { line = it } != null) {
            line?.let { deviceLine ->
                if (deviceLine.isNotBlank()) {
                    val parts = deviceLine.split(Regex("\\s+"))
                    if (parts.size >= 2) {
                        val id = parts[0]
                        val status = when (parts[1]) {
                            "device" -> DeviceStatus.ONLINE
                            "offline" -> DeviceStatus.OFFLINE
                            "unauthorized" -> DeviceStatus.UNAUTHORIZED
                            else -> DeviceStatus.OFFLINE
                        }
                        
                        val model = parts.find { it.startsWith("model:") }
                            ?.substringAfter(":")
                            ?: "Unknown"
                        
                        devices.add(
                            AndroidDevice(
                                id = id,
                                model = model.replace("_", " "),
                                androidVersion = getAndroidVersion(id),
                                status = status
                            )
                        )
                    }
                }
            }
        }
        
        process.waitFor()
    } catch (e: Exception) {
    }
    
    devices
}

private fun getAndroidVersion(deviceId: String): String {
    return try {
        val process = ProcessBuilder()
            .command("adb", "-s", deviceId, "shell", "getprop", "ro.build.version.release")
            .redirectErrorStream(true)
            .start()
        
        val reader = BufferedReader(InputStreamReader(process.inputStream))
        val version = reader.readLine()?.trim() ?: "Unknown"
        process.waitFor()
        version
    } catch (e: Exception) {
        "Unknown"
    }
}

suspend fun installApk(device: AndroidDevice, apkPath: String): Boolean = withContext(Dispatchers.IO) {
    try {
        val process = ProcessBuilder()
            .command("adb", "-s", device.id, "install", "-r", apkPath)
            .redirectErrorStream(true)
            .start()
        
        val exitCode = process.waitFor()
        exitCode == 0
    } catch (e: Exception) {
        false
    }
}
