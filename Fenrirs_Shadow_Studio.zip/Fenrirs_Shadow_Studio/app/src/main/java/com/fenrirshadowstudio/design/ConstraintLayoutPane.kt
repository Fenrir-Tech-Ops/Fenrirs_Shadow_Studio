package com.fenrirshadowstudio.design

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

data class ViewComponent(
    val id: String,
    val type: ViewType,
    var position: Offset,
    var width: Float,
    var height: Float,
    val constraints: MutableList<Constraint> = mutableListOf()
)

enum class ViewType {
    BUTTON, TEXT_VIEW, IMAGE_VIEW, EDIT_TEXT, RECYCLER_VIEW, CARD_VIEW
}

data class Constraint(
    val from: ConstraintAnchor,
    val to: ConstraintAnchor,
    val targetId: String
)

enum class ConstraintAnchor {
    TOP, BOTTOM, START, END, BASELINE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConstraintLayoutPane(
    onSaveLayout: (List<ViewComponent>) -> Unit,
    modifier: Modifier = Modifier
) {
    var components by remember { mutableStateOf(listOf<ViewComponent>()) }
    var selectedComponent by remember { mutableStateOf<ViewComponent?>(null) }
    var showComponentPalette by remember { mutableStateOf(true) }
    
    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("ConstraintLayout Editor") },
            actions = {
                IconButton(onClick = { showComponentPalette = !showComponentPalette }) {
                    Icon(
                        imageVector = if (showComponentPalette) Icons.Default.ViewSidebar else Icons.Default.ViewModule,
                        contentDescription = "Toggle Palette"
                    )
                }
                
                IconButton(onClick = { components = emptyList() }) {
                    Icon(Icons.Default.Clear, "Clear")
                }
                
                IconButton(onClick = { onSaveLayout(components) }) {
                    Icon(Icons.Default.Save, "Save")
                }
            }
        )
        
        Row(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            if (showComponentPalette) {
                ComponentPalette(
                    onComponentSelected = { type ->
                        val newComponent = ViewComponent(
                            id = "view_${System.currentTimeMillis()}",
                            type = type,
                            position = Offset(100f, 100f),
                            width = 200f,
                            height = when (type) {
                                ViewType.BUTTON -> 80f
                                ViewType.TEXT_VIEW -> 60f
                                ViewType.EDIT_TEXT -> 80f
                                ViewType.IMAGE_VIEW -> 200f
                                ViewType.RECYCLER_VIEW -> 400f
                                ViewType.CARD_VIEW -> 300f
                            }
                        )
                        components = components + newComponent
                        selectedComponent = newComponent
                    },
                    modifier = Modifier
                        .width(200.dp)
                        .fillMaxHeight()
                )
                
                Divider(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.dp)
                )
            }
            
            Canvas(
                components = components,
                selectedComponent = selectedComponent,
                onComponentSelected = { selectedComponent = it },
                onComponentMoved = { component, offset ->
                    components = components.map {
                        if (it.id == component.id) it.copy(position = offset) else it
                    }
                },
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f)
            )
            
            selectedComponent?.let { component ->
                Divider(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.dp)
                )
                
                PropertiesPanel(
                    component = component,
                    allComponents = components,
                    onPropertyChanged = { updated ->
                        components = components.map {
                            if (it.id == updated.id) updated else it
                        }
                    },
                    onDelete = {
                        components = components.filter { it.id != component.id }
                        selectedComponent = null
                    },
                    modifier = Modifier
                        .width(300.dp)
                        .fillMaxHeight()
                )
            }
        }
    }
}

@Composable
private fun ComponentPalette(
    onComponentSelected: (ViewType) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Component Palette",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ViewType.entries) { type ->
                    ComponentPaletteItem(
                        type = type,
                        onClick = { onComponentSelected(type) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ComponentPaletteItem(
    type: ViewType,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = when (type) {
                ViewType.BUTTON -> Icons.Default.SmartButton
                ViewType.TEXT_VIEW -> Icons.Default.TextFields
                ViewType.IMAGE_VIEW -> Icons.Default.Image
                ViewType.EDIT_TEXT -> Icons.Default.Edit
                ViewType.RECYCLER_VIEW -> Icons.Default.List
                ViewType.CARD_VIEW -> Icons.Default.CreditCard
            },
            contentDescription = null,
            modifier = Modifier.size(20.dp)
        )
        
        Spacer(Modifier.width(8.dp))
        
        Text(type.name.replace("_", " "))
    }
}

@Composable
private fun Canvas(
    components: List<ViewComponent>,
    selectedComponent: ViewComponent?,
    onComponentSelected: (ViewComponent) -> Unit,
    onComponentMoved: (ViewComponent, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFFF5F5F5))
            .padding(16.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                components.forEach { component ->
                    DraggableView(
                        component = component,
                        isSelected = selectedComponent?.id == component.id,
                        onSelected = { onComponentSelected(component) },
                        onDragged = { offset -> onComponentMoved(component, offset) }
                    )
                }
            }
        }
    }
}

@Composable
private fun DraggableView(
    component: ViewComponent,
    isSelected: Boolean,
    onSelected: () -> Unit,
    onDragged: (Offset) -> Unit
) {
    var offsetX by remember { mutableFloatStateOf(component.position.x) }
    var offsetY by remember { mutableFloatStateOf(component.position.y) }
    
    LaunchedEffect(component.position) {
        offsetX = component.position.x
        offsetY = component.position.y
    }
    
    Surface(
        modifier = Modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .size(component.width.dp, component.height.dp)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray
            )
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onSelected()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                    onDragged(Offset(offsetX, offsetY))
                }
            },
        color = when (component.type) {
            ViewType.BUTTON -> MaterialTheme.colorScheme.primaryContainer
            ViewType.TEXT_VIEW -> Color.Transparent
            ViewType.EDIT_TEXT -> MaterialTheme.colorScheme.surfaceVariant
            ViewType.IMAGE_VIEW -> Color.LightGray
            ViewType.RECYCLER_VIEW -> MaterialTheme.colorScheme.surfaceVariant
            ViewType.CARD_VIEW -> MaterialTheme.colorScheme.surface
        },
        tonalElevation = if (component.type == ViewType.CARD_VIEW) 2.dp else 0.dp
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = component.type.name.replace("_", " "),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun PropertiesPanel(
    component: ViewComponent,
    allComponents: List<ViewComponent>,
    onPropertyChanged: (ViewComponent) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Properties",
                    style = MaterialTheme.typography.titleMedium
                )
                
                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Default.Delete,
                        "Delete",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            OutlinedTextField(
                value = component.id,
                onValueChange = { onPropertyChanged(component.copy(id = it)) },
                label = { Text("ID") },
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = component.width.toInt().toString(),
                    onValueChange = {
                        it.toFloatOrNull()?.let { w ->
                            onPropertyChanged(component.copy(width = w))
                        }
                    },
                    label = { Text("Width") },
                    modifier = Modifier.weight(1f)
                )
                
                OutlinedTextField(
                    value = component.height.toInt().toString(),
                    onValueChange = {
                        it.toFloatOrNull()?.let { h ->
                            onPropertyChanged(component.copy(height = h))
                        }
                    },
                    label = { Text("Height") },
                    modifier = Modifier.weight(1f)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "Constraints",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Constraint editing coming soon",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}
