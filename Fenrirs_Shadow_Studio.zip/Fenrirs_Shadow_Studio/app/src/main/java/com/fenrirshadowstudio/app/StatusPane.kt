package com.fenrirshadowstudio.app

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

data class StatusInfo(
    val filePath: String = "",
    val lineNumber: Int = 1,
    val columnNumber: Int = 1,
    val language: String = "",
    val encoding: String = "UTF-8",
    val lineEnding: String = "LF",
    val gitBranch: String? = null,
    val buildStatus: String? = null,
    val message: String? = null
)

@Composable
fun StatusPane(
    status: StatusInfo,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (status.message != null) {
                    Text(
                        text = status.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                } else if (status.filePath.isNotEmpty()) {
                    Text(
                        text = status.filePath,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                }
            }
            
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (status.gitBranch != null) {
                    StatusItem(
                        label = "Branch",
                        value = status.gitBranch,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
                
                if (status.buildStatus != null) {
                    StatusItem(
                        label = "Build",
                        value = status.buildStatus,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                if (status.filePath.isNotEmpty()) {
                    StatusItem(
                        label = "Ln",
                        value = status.lineNumber.toString()
                    )
                    
                    StatusItem(
                        label = "Col",
                        value = status.columnNumber.toString()
                    )
                    
                    if (status.language.isNotEmpty()) {
                        StatusItem(
                            label = null,
                            value = status.language.uppercase(),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    
                    StatusItem(
                        label = null,
                        value = status.encoding
                    )
                    
                    StatusItem(
                        label = null,
                        value = status.lineEnding
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusItem(
    label: String?,
    value: String,
    color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (label != null) {
            Text(
                text = "$label:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
        
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = color
        )
    }
}
