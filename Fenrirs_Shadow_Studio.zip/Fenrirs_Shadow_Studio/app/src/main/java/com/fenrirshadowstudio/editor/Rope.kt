package com.fenrirshadowstudio.editor

import kotlin.math.max
import kotlin.math.min

sealed class Rope {
    abstract val length: Int
    abstract val height: Int
    abstract val lineCount: Int
    
    abstract fun charAt(index: Int): Char
    abstract fun substring(start: Int, end: Int): String
    abstract fun insert(index: Int, text: String): Rope
    abstract fun delete(start: Int, end: Int): Rope
    abstract fun lineAt(line: Int): String
    abstract fun lineStart(line: Int): Int
    
    data class Leaf(val text: String) : Rope() {
        override val length: Int = text.length
        override val height: Int = 0
        override val lineCount: Int = text.count { it == '\n' } + 1
        
        override fun charAt(index: Int): Char {
            require(index in 0 until length) { "Index out of bounds: $index" }
            return text[index]
        }
        
        override fun substring(start: Int, end: Int): String {
            return text.substring(start, end)
        }
        
        override fun insert(index: Int, text: String): Rope {
            val newText = this.text.substring(0, index) + text + this.text.substring(index)
            return if (newText.length > MAX_LEAF_SIZE) {
                val mid = newText.length / 2
                Node(Leaf(newText.substring(0, mid)), Leaf(newText.substring(mid)))
            } else {
                Leaf(newText)
            }
        }
        
        override fun delete(start: Int, end: Int): Rope {
            val newText = text.substring(0, start) + text.substring(end)
            return Leaf(newText)
        }
        
        override fun lineAt(line: Int): String {
            val lines = text.split('\n')
            return if (line < lines.size) lines[line] else ""
        }
        
        override fun lineStart(line: Int): Int {
            var currentLine = 0
            var pos = 0
            while (currentLine < line && pos < length) {
                if (text[pos] == '\n') currentLine++
                pos++
            }
            return if (currentLine == line) pos else length
        }
        
        override fun toString(): String = text
    }
    
    data class Node(val left: Rope, val right: Rope) : Rope() {
        override val length: Int = left.length + right.length
        override val height: Int = max(left.height, right.height) + 1
        override val lineCount: Int = left.lineCount + right.lineCount - 1
        
        override fun charAt(index: Int): Char {
            require(index in 0 until length) { "Index out of bounds: $index" }
            return if (index < left.length) {
                left.charAt(index)
            } else {
                right.charAt(index - left.length)
            }
        }
        
        override fun substring(start: Int, end: Int): String {
            return buildString {
                if (start < left.length) {
                    append(left.substring(start, min(end, left.length)))
                }
                if (end > left.length) {
                    append(right.substring(max(0, start - left.length), end - left.length))
                }
            }
        }
        
        override fun insert(index: Int, text: String): Rope {
            return if (index <= left.length) {
                Node(left.insert(index, text), right).rebalance()
            } else {
                Node(left, right.insert(index - left.length, text)).rebalance()
            }
        }
        
        override fun delete(start: Int, end: Int): Rope {
            return when {
                end <= left.length -> {
                    Node(left.delete(start, end), right).rebalance()
                }
                start >= left.length -> {
                    Node(left, right.delete(start - left.length, end - left.length)).rebalance()
                }
                else -> {
                    Node(
                        left.delete(start, left.length),
                        right.delete(0, end - left.length)
                    ).rebalance()
                }
            }
        }
        
        override fun lineAt(line: Int): String {
            val leftLines = left.lineCount
            return if (line < leftLines - 1) {
                left.lineAt(line)
            } else if (line == leftLines - 1) {
                val leftLast = left.lineAt(leftLines - 1)
                val rightFirst = right.lineAt(0)
                leftLast + rightFirst
            } else {
                right.lineAt(line - leftLines + 1)
            }
        }
        
        override fun lineStart(line: Int): Int {
            val leftLines = left.lineCount
            return if (line < leftLines) {
                left.lineStart(line)
            } else {
                left.length + right.lineStart(line - leftLines + 1)
            }
        }
        
        private fun rebalance(): Rope {
            val balanceFactor = left.height - right.height
            
            return when {
                balanceFactor > 1 && left is Node -> {
                    if (left.left.height >= left.right.height) {
                        rotateRight()
                    } else {
                        Node(left.rotateLeft(), right).rotateRight()
                    }
                }
                balanceFactor < -1 && right is Node -> {
                    if (right.right.height >= right.left.height) {
                        rotateLeft()
                    } else {
                        Node(left, right.rotateRight()).rotateLeft()
                    }
                }
                else -> this
            }
        }
        
        private fun rotateLeft(): Rope {
            require(right is Node)
            return Node(Node(left, right.left), right.right)
        }
        
        private fun rotateRight(): Rope {
            require(left is Node)
            return Node(left.left, Node(left.right, right))
        }
        
        override fun toString(): String = substring(0, length)
    }
    
    companion object {
        const val MAX_LEAF_SIZE = 1024
        
        fun from(text: String): Rope {
            return if (text.length <= MAX_LEAF_SIZE) {
                Leaf(text)
            } else {
                val mid = text.length / 2
                Node(from(text.substring(0, mid)), from(text.substring(mid)))
            }
        }
        
        fun empty(): Rope = Leaf("")
    }
}
