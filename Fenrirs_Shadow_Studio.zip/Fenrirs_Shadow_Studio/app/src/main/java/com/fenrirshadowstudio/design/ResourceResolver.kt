package com.fenrirshadowstudio.design

import androidx.compose.ui.graphics.Color
import org.w3c.dom.Document
import org.w3c.dom.Element
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory

data class AndroidResource(
    val name: String,
    val type: ResourceType,
    val value: String,
    val qualifier: String? = null
)

enum class ResourceType {
    STRING, COLOR, DIMEN, DRAWABLE, LAYOUT, STYLE, ATTR
}

class ResourceResolver(private val projectRoot: File) {
    private val resources = mutableMapOf<ResourceType, MutableMap<String, String>>()
    
    init {
        loadResources()
    }
    
    fun getString(name: String): String? {
        return resources[ResourceType.STRING]?.get(name)
    }
    
    fun getColor(name: String): Color? {
        val colorValue = resources[ResourceType.COLOR]?.get(name) ?: return null
        return parseColor(colorValue)
    }
    
    fun getDimen(name: String): String? {
        return resources[ResourceType.DIMEN]?.get(name)
    }
    
    fun getAllResources(type: ResourceType): Map<String, String> {
        return resources[type] ?: emptyMap()
    }
    
    fun addResource(type: ResourceType, name: String, value: String) {
        resources.getOrPut(type) { mutableMapOf() }[name] = value
    }
    
    fun removeResource(type: ResourceType, name: String) {
        resources[type]?.remove(name)
    }
    
    fun saveResources() {
        val resDir = File(projectRoot, "app/src/main/res")
        if (!resDir.exists()) return
        
        saveStrings(File(resDir, "values/strings.xml"))
        saveColors(File(resDir, "values/colors.xml"))
        saveDimens(File(resDir, "values/dimens.xml"))
    }
    
    private fun loadResources() {
        val resDir = File(projectRoot, "app/src/main/res")
        if (!resDir.exists()) return
        
        loadFromXml(File(resDir, "values/strings.xml"), ResourceType.STRING)
        loadFromXml(File(resDir, "values/colors.xml"), ResourceType.COLOR)
        loadFromXml(File(resDir, "values/dimens.xml"), ResourceType.DIMEN)
        loadFromXml(File(resDir, "values/styles.xml"), ResourceType.STYLE)
    }
    
    private fun loadFromXml(file: File, type: ResourceType) {
        if (!file.exists()) return
        
        try {
            val factory = DocumentBuilderFactory.newInstance()
            val builder = factory.newDocumentBuilder()
            val doc: Document = builder.parse(file)
            
            val resourceMap = resources.getOrPut(type) { mutableMapOf() }
            
            val items = when (type) {
                ResourceType.STRING -> doc.getElementsByTagName("string")
                ResourceType.COLOR -> doc.getElementsByTagName("color")
                ResourceType.DIMEN -> doc.getElementsByTagName("dimen")
                ResourceType.STYLE -> doc.getElementsByTagName("style")
                else -> return
            }
            
            for (i in 0 until items.length) {
                val item = items.item(i) as? Element ?: continue
                val name = item.getAttribute("name")
                val value = item.textContent
                
                if (name.isNotEmpty()) {
                    resourceMap[name] = value
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    private fun saveStrings(file: File) {
        saveResourceXml(file, ResourceType.STRING, "string")
    }
    
    private fun saveColors(file: File) {
        saveResourceXml(file, ResourceType.COLOR, "color")
    }
    
    private fun saveDimens(file: File) {
        saveResourceXml(file, ResourceType.DIMEN, "dimen")
    }
    
    private fun saveResourceXml(file: File, type: ResourceType, tagName: String) {
        val resourceMap = resources[type] ?: return
        
        file.parentFile?.mkdirs()
        
        val xml = buildString {
            appendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
            appendLine("<resources>")
            
            resourceMap.forEach { (name, value) ->
                appendLine("    <$tagName name=\"$name\">$value</$tagName>")
            }
            
            appendLine("</resources>")
        }
        
        file.writeText(xml)
    }
    
    private fun parseColor(colorString: String): Color? {
        if (!colorString.startsWith("#")) return null
        
        return try {
            val hex = colorString.substring(1)
            val color = when (hex.length) {
                6 -> {
                    val rgb = hex.toLong(16)
                    Color(((rgb shr 16) and 0xFF).toInt(), ((rgb shr 8) and 0xFF).toInt(), (rgb and 0xFF).toInt())
                }
                8 -> {
                    val argb = hex.toLong(16)
                    Color(
                        ((argb shr 16) and 0xFF).toInt(),
                        ((argb shr 8) and 0xFF).toInt(),
                        (argb and 0xFF).toInt(),
                        ((argb shr 24) and 0xFF).toInt()
                    )
                }
                else -> null
            }
            color
        } catch (e: Exception) {
            null
        }
    }
}

data class DrawableResource(
    val name: String,
    val file: File,
    val type: DrawableType
)

enum class DrawableType {
    BITMAP, VECTOR, NINE_PATCH, SHAPE
}

class DrawableResolver(private val projectRoot: File) {
    fun getAllDrawables(): List<DrawableResource> {
        val drawables = mutableListOf<DrawableResource>()
        val resDir = File(projectRoot, "app/src/main/res")
        
        if (!resDir.exists()) return drawables
        
        resDir.listFiles()?.filter { it.name.startsWith("drawable") }?.forEach { drawableDir ->
            drawableDir.listFiles()?.forEach { file ->
                val type = when (file.extension) {
                    "xml" -> DrawableType.VECTOR
                    "png" -> if (file.name.endsWith(".9.png")) DrawableType.NINE_PATCH else DrawableType.BITMAP
                    "jpg", "jpeg", "webp" -> DrawableType.BITMAP
                    else -> return@forEach
                }
                
                drawables.add(
                    DrawableResource(
                        name = file.nameWithoutExtension,
                        file = file,
                        type = type
                    )
                )
            }
        }
        
        return drawables
    }
    
    fun getDrawable(name: String): DrawableResource? {
        return getAllDrawables().find { it.name == name }
    }
}
