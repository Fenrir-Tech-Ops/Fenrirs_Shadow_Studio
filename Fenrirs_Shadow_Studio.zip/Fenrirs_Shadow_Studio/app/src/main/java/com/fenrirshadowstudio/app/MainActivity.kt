package com.fenrirshadowstudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fenrirshadowstudio.build.BuildPane
import com.fenrirshadowstudio.debug.DebugPane
import com.fenrirshadowstudio.design.ConstraintLayoutPane
import com.fenrirshadowstudio.design.XmlDesignPane
import com.fenrirshadowstudio.device.DevicePane
import com.fenrirshadowstudio.editor.TabbedEditorPane
import com.fenrirshadowstudio.project.ProjectPane
import com.fenrirshadowstudio.witness.VerifyPane
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            FenrirsShadowStudioTheme {
                FenrirsShadowStudioApp()
            }
        }
    }
}

@Composable
fun FenrirsShadowStudioTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF82B1FF),
            secondary = androidx.compose.ui.graphics.Color(0xFF448AFF),
            tertiary = androidx.compose.ui.graphics.Color(0xFFFF6E40),
            background = androidx.compose.ui.graphics.Color(0xFF1E1E1E),
            surface = androidx.compose.ui.graphics.Color(0xFF2D2D2D),
            onPrimary = androidx.compose.ui.graphics.Color.White,
            onSecondary = androidx.compose.ui.graphics.Color.White,
            onBackground = androidx.compose.ui.graphics.Color(0xFFE0E0E0),
            onSurface = androidx.compose.ui.graphics.Color(0xFFE0E0E0)
        )
    } else {
        lightColorScheme()
    }
    
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}

enum class NavigationPane {
    PROJECT, EDITOR, BUILD, DEVICE, DEBUG, DESIGN, CONSTRAINT, VERIFY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FenrirsShadowStudioApp() {
    var currentPane by remember { mutableStateOf(NavigationPane.EDITOR) }
    var projectRoot by remember { mutableStateOf<File?>(null) }
    var statusInfo by remember { mutableStateOf(StatusInfo()) }
    var isDarkTheme by remember { mutableStateOf(true) }
    
    FenrirsShadowStudioTheme(darkTheme = isDarkTheme) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { 
                        Text(
                            text = "Fenrir's Shadow Studio",
                            style = MaterialTheme.typography.titleLarge
                        ) 
                    },
                    actions = {
                        IconButton(onClick = { isDarkTheme = !isDarkTheme }) {
                            Icon(
                                imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Theme"
                            )
                        }
                        
                        IconButton(onClick = { }) {
                            Icon(Icons.Default.Settings, "Settings")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                StatusPane(status = statusInfo)
            }
        ) { paddingValues ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                NavigationRail(
                    currentPane = currentPane,
                    onPaneSelected = { currentPane = it },
                    modifier = Modifier.fillMaxHeight()
                )
                
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    when (currentPane) {
                        NavigationPane.PROJECT -> {
                            ProjectPane(
                                projectRoot = projectRoot,
                                onFileSelected = { file ->
                                    statusInfo = statusInfo.copy(filePath = file.absolutePath)
                                },
                                onFileCreated = { file, content ->
                                    file.parentFile?.mkdirs()
                                    file.writeText(content)
                                },
                                onFolderCreated = { folder, _ ->
                                    folder.mkdirs()
                                }
                            )
                        }
                        
                        NavigationPane.EDITOR -> {
                            TabbedEditorPane()
                        }
                        
                        NavigationPane.BUILD -> {
                            BuildPane(
                                projectRoot = projectRoot,
                                onFileNavigate = { file, line ->
                                    statusInfo = statusInfo.copy(
                                        filePath = file,
                                        lineNumber = line
                                    )
                                }
                            )
                        }
                        
                        NavigationPane.DEVICE -> {
                            DevicePane(
                                onDeviceSelected = { device ->
                                    statusInfo = statusInfo.copy(
                                        message = "Connected to ${device.model}"
                                    )
                                },
                                onInstallApk = { device, apkPath ->
                                    statusInfo = statusInfo.copy(
                                        message = "Installing APK on ${device.model}"
                                    )
                                }
                            )
                        }
                        
                        NavigationPane.DEBUG -> {
                            DebugPane(
                                onFileNavigate = { file, line ->
                                    statusInfo = statusInfo.copy(
                                        filePath = file,
                                        lineNumber = line
                                    )
                                }
                            )
                        }
                        
                        NavigationPane.DESIGN -> {
                            XmlDesignPane(
                                xmlContent = "",
                                onXmlChanged = { }
                            )
                        }
                        
                        NavigationPane.CONSTRAINT -> {
                            ConstraintLayoutPane(
                                onSaveLayout = { }
                            )
                        }
                        
                        NavigationPane.VERIFY -> {
                            VerifyPane(
                                projectRoot = projectRoot,
                                onFileNavigate = { file, line ->
                                    statusInfo = statusInfo.copy(
                                        filePath = file,
                                        lineNumber = line
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavigationRail(
    currentPane: NavigationPane,
    onPaneSelected: (NavigationPane) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationRail(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        
        NavigationRailItem(
            selected = currentPane == NavigationPane.PROJECT,
            onClick = { onPaneSelected(NavigationPane.PROJECT) },
            icon = { Icon(Icons.Default.Folder, "Project") },
            label = { Text("Project") }
        )
        
        NavigationRailItem(
            selected = currentPane == NavigationPane.EDITOR,
            onClick = { onPaneSelected(NavigationPane.EDITOR) },
            icon = { Icon(Icons.Default.Code, "Editor") },
            label = { Text("Editor") }
        )
        
        NavigationRailItem(
            selected = currentPane == NavigationPane.BUILD,
            onClick = { onPaneSelected(NavigationPane.BUILD) },
            icon = { Icon(Icons.Default.Build, "Build") },
            label = { Text("Build") }
        )
        
        NavigationRailItem(
            selected = currentPane == NavigationPane.DEVICE,
            onClick = { onPaneSelected(NavigationPane.DEVICE) },
            icon = { Icon(Icons.Default.PhoneAndroid, "Devices") },
            label = { Text("Devices") }
        )
        
        NavigationRailItem(
            selected = currentPane == NavigationPane.DEBUG,
            onClick = { onPaneSelected(NavigationPane.DEBUG) },
            icon = { Icon(Icons.Default.BugReport, "Debug") },
            label = { Text("Debug") }
        )
        
        NavigationRailItem(
            selected = currentPane == NavigationPane.DESIGN,
            onClick = { onPaneSelected(NavigationPane.DESIGN) },
            icon = { Icon(Icons.Default.DesignServices, "Design") },
            label = { Text("Design") }
        )
        
        NavigationRailItem(
            selected = currentPane == NavigationPane.CONSTRAINT,
            onClick = { onPaneSelected(NavigationPane.CONSTRAINT) },
            icon = { Icon(Icons.Default.GridOn, "Layout") },
            label = { Text("Layout") }
        )
        
        NavigationRailItem(
            selected = currentPane == NavigationPane.VERIFY,
            onClick = { onPaneSelected(NavigationPane.VERIFY) },
            icon = { Icon(Icons.Default.Verified, "Verify") },
            label = { Text("Quality") }
        )
    }
}
