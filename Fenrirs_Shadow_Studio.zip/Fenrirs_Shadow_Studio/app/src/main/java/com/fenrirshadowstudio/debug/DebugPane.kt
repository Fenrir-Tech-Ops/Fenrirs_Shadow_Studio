package com.fenrirshadowstudio.debug

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

data class Breakpoint(
    val id: String,
    val file: String,
    val line: Int,
    val enabled: Boolean = true,
    val condition: String? = null
)

data class Variable(
    val name: String,
    val type: String,
    val value: String,
    val children: List<Variable> = emptyList()
)

data class StackFrame(
    val function: String,
    val file: String,
    val line: Int,
    val module: String
)

enum class DebugState {
    IDLE, RUNNING, PAUSED, STOPPED
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DebugPane(
    onFileNavigate: (String, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var debugState by remember { mutableStateOf(DebugState.IDLE) }
    var breakpoints by remember { mutableStateOf(listOf<Breakpoint>()) }
    var variables by remember { mutableStateOf(listOf<Variable>()) }
    var callStack by remember { mutableStateOf(listOf<StackFrame>()) }
    var selectedTab by remember { mutableStateOf(0) }
    
    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Debug") },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = when (debugState) {
                    DebugState.PAUSED -> MaterialTheme.colorScheme.tertiaryContainer
                    DebugState.RUNNING -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surface
                }
            )
        )
        
        DebugToolbar(
            debugState = debugState,
            onStart = { debugState = DebugState.RUNNING },
            onPause = { debugState = DebugState.PAUSED },
            onStop = { debugState = DebugState.STOPPED },
            onStepOver = { },
            onStepInto = { },
            onStepOut = { },
            onContinue = { debugState = DebugState.RUNNING },
            modifier = Modifier.fillMaxWidth()
        )
        
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Breakpoints") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Variables") }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Call Stack") }
            )
        }
        
        when (selectedTab) {
            0 -> BreakpointsTab(
                breakpoints = breakpoints,
                onToggle = { breakpoint ->
                    breakpoints = breakpoints.map {
                        if (it.id == breakpoint.id) it.copy(enabled = !it.enabled) else it
                    }
                },
                onDelete = { breakpoint ->
                    breakpoints = breakpoints.filter { it.id != breakpoint.id }
                },
                onNavigate = onFileNavigate,
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
            
            1 -> VariablesTab(
                variables = variables,
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
            
            2 -> CallStackTab(
                frames = callStack,
                onNavigate = onFileNavigate,
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
        }
    }
}

@Composable
private fun DebugToolbar(
    debugState: DebugState,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit,
    onStepOver: () -> Unit,
    onStepInto: () -> Unit,
    onStepOut: () -> Unit,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onStart,
                enabled = debugState == DebugState.IDLE || debugState == DebugState.STOPPED
            ) {
                Icon(Icons.Default.PlayArrow, "Start")
            }
            
            IconButton(
                onClick = onPause,
                enabled = debugState == DebugState.RUNNING
            ) {
                Icon(Icons.Default.Pause, "Pause")
            }
            
            IconButton(
                onClick = onStop,
                enabled = debugState != DebugState.IDLE
            ) {
                Icon(Icons.Default.Stop, "Stop")
            }
            
            Divider(
                modifier = Modifier
                    .height(32.dp)
                    .width(1.dp)
            )
            
            IconButton(
                onClick = onContinue,
                enabled = debugState == DebugState.PAUSED
            ) {
                Icon(Icons.Default.PlayArrow, "Continue")
            }
            
            IconButton(
                onClick = onStepOver,
                enabled = debugState == DebugState.PAUSED
            ) {
                Icon(Icons.Default.ArrowForward, "Step Over")
            }
            
            IconButton(
                onClick = onStepInto,
                enabled = debugState == DebugState.PAUSED
            ) {
                Icon(Icons.Default.ArrowDownward, "Step Into")
            }
            
            IconButton(
                onClick = onStepOut,
                enabled = debugState == DebugState.PAUSED
            ) {
                Icon(Icons.Default.ArrowUpward, "Step Out")
            }
        }
    }
}

@Composable
private fun BreakpointsTab(
    breakpoints: List<Breakpoint>,
    onToggle: (Breakpoint) -> Unit,
    onDelete: (Breakpoint) -> Unit,
    onNavigate: (String, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    if (breakpoints.isEmpty()) {
        EmptyBreakpointsView(modifier = modifier)
    } else {
        LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(8.dp)
        ) {
            items(breakpoints) { breakpoint ->
                BreakpointItem(
                    breakpoint = breakpoint,
                    onToggle = { onToggle(breakpoint) },
                    onDelete = { onDelete(breakpoint) },
                    onClick = { onNavigate(breakpoint.file, breakpoint.line) }
                )
            }
        }
    }
}

@Composable
private fun BreakpointItem(
    breakpoint: Breakpoint,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clickable(onClick = onClick),
        tonalElevation = 1.dp,
        shape = MaterialTheme.shapes.small
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = breakpoint.enabled,
                onCheckedChange = { onToggle() }
            )
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${breakpoint.file}:${breakpoint.line}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Monospace
                )
                
                if (breakpoint.condition != null) {
                    Text(
                        text = "Condition: ${breakpoint.condition}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
            
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete,
                    "Delete",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun VariablesTab(
    variables: List<Variable>,
    modifier: Modifier = Modifier
) {
    if (variables.isEmpty()) {
        EmptyVariablesView(modifier = modifier)
    } else {
        LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(8.dp)
        ) {
            items(variables) { variable ->
                VariableItem(variable = variable, depth = 0)
            }
        }
    }
}

@Composable
private fun VariableItem(
    variable: Variable,
    depth: Int
) {
    var isExpanded by remember { mutableStateOf(false) }
    
    Column {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp)
                .clickable(enabled = variable.children.isNotEmpty()) {
                    isExpanded = !isExpanded
                },
            tonalElevation = 0.5.dp
        ) {
            Row(
                modifier = Modifier.padding(
                    start = (16 * depth).dp,
                    top = 8.dp,
                    bottom = 8.dp,
                    end = 8.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (variable.children.isNotEmpty()) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowRight,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                }
                
                Text(
                    text = variable.name,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f),
                    fontFamily = FontFamily.Monospace
                )
                
                Text(
                    text = variable.type,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontFamily = FontFamily.Monospace
                )
                
                Text(
                    text = variable.value,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
        
        if (isExpanded && variable.children.isNotEmpty()) {
            variable.children.forEach { child ->
                VariableItem(variable = child, depth = depth + 1)
            }
        }
    }
}

@Composable
private fun CallStackTab(
    frames: List<StackFrame>,
    onNavigate: (String, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    if (frames.isEmpty()) {
        EmptyCallStackView(modifier = modifier)
    } else {
        LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(8.dp)
        ) {
            items(frames) { frame ->
                StackFrameItem(
                    frame = frame,
                    onClick = { onNavigate(frame.file, frame.line) }
                )
            }
        }
    }
}

@Composable
private fun StackFrameItem(
    frame: StackFrame,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clickable(onClick = onClick),
        tonalElevation = 1.dp,
        shape = MaterialTheme.shapes.small
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = frame.function,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace
            )
            
            Text(
                text = "${frame.file}:${frame.line}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                fontFamily = FontFamily.Monospace
            )
            
            Text(
                text = frame.module,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun EmptyBreakpointsView(modifier: Modifier = Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Text(
            text = "No breakpoints set",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )
    }
}

@Composable
private fun EmptyVariablesView(modifier: Modifier = Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Text(
            text = "No variables to display",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )
    }
}

@Composable
private fun EmptyCallStackView(modifier: Modifier = Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Text(
            text = "No call stack available",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )
    }
}
