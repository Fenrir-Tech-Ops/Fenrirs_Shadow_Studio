package com.fenrirshadowstudio.editor

import androidx.compose.ui.graphics.Color

enum class TokenType {
    KEYWORD,
    IDENTIFIER,
    STRING,
    NUMBER,
    COMMENT,
    OPERATOR,
    PUNCTUATION,
    TYPE,
    FUNCTION,
    ANNOTATION,
    XML_TAG,
    XML_ATTRIBUTE,
    XML_VALUE,
    DEFAULT
}

data class Token(
    val type: TokenType,
    val start: Int,
    val end: Int,
    val text: String
)

object SyntaxHighlighter {
    private val kotlinKeywords = setOf(
        "abstract", "actual", "annotation", "as", "break", "by", "catch", "class",
        "companion", "const", "constructor", "continue", "crossinline", "data",
        "delegate", "do", "dynamic", "else", "enum", "expect", "external", "false",
        "field", "file", "final", "finally", "for", "fun", "get", "if", "import",
        "in", "infix", "init", "inline", "inner", "interface", "internal", "is",
        "lateinit", "noinline", "null", "object", "open", "operator", "out",
        "override", "package", "param", "private", "property", "protected", "public",
        "receiver", "reified", "return", "sealed", "set", "setparam", "super",
        "suspend", "tailrec", "this", "throw", "true", "try", "typealias", "typeof",
        "val", "var", "vararg", "when", "where", "while"
    )
    
    private val kotlinTypes = setOf(
        "String", "Int", "Long", "Float", "Double", "Boolean", "Char", "Byte",
        "Short", "Unit", "Nothing", "Any", "Array", "List", "Set", "Map",
        "MutableList", "MutableSet", "MutableMap", "Collection", "Iterable",
        "Sequence", "Pair", "Triple"
    )
    
    fun tokenize(code: String, language: String = "kotlin"): List<Token> {
        return when (language.lowercase()) {
            "kotlin" -> tokenizeKotlin(code)
            "xml" -> tokenizeXml(code)
            "json" -> tokenizeJson(code)
            else -> listOf(Token(TokenType.DEFAULT, 0, code.length, code))
        }
    }
    
    private fun tokenizeKotlin(code: String): List<Token> {
        val tokens = mutableListOf<Token>()
        var i = 0
        
        while (i < code.length) {
            when {
                code[i].isWhitespace() -> {
                    i++
                }
                
                code.startsWith("//", i) -> {
                    val start = i
                    while (i < code.length && code[i] != '\n') i++
                    tokens.add(Token(TokenType.COMMENT, start, i, code.substring(start, i)))
                }
                
                code.startsWith("/*", i) -> {
                    val start = i
                    i += 2
                    while (i < code.length - 1 && !code.startsWith("*/", i)) i++
                    if (i < code.length - 1) i += 2
                    tokens.add(Token(TokenType.COMMENT, start, i, code.substring(start, i)))
                }
                
                code[i] == '@' -> {
                    val start = i
                    i++
                    while (i < code.length && (code[i].isLetterOrDigit() || code[i] == '_')) i++
                    tokens.add(Token(TokenType.ANNOTATION, start, i, code.substring(start, i)))
                }
                
                code[i] == '"' -> {
                    val start = i
                    i++
                    val isTriple = code.startsWith("\"\"", i)
                    if (isTriple) i += 2
                    
                    while (i < code.length) {
                        if (isTriple && code.startsWith("\"\"\"", i)) {
                            i += 3
                            break
                        } else if (!isTriple && code[i] == '"' && code[i - 1] != '\\') {
                            i++
                            break
                        }
                        i++
                    }
                    tokens.add(Token(TokenType.STRING, start, i, code.substring(start, i)))
                }
                
                code[i].isDigit() -> {
                    val start = i
                    while (i < code.length && (code[i].isDigit() || code[i] in "._xXbBfFlL")) i++
                    tokens.add(Token(TokenType.NUMBER, start, i, code.substring(start, i)))
                }
                
                code[i].isLetter() || code[i] == '_' -> {
                    val start = i
                    while (i < code.length && (code[i].isLetterOrDigit() || code[i] == '_')) i++
                    val text = code.substring(start, i)
                    
                    val type = when {
                        text in kotlinKeywords -> TokenType.KEYWORD
                        text in kotlinTypes -> TokenType.TYPE
                        text[0].isUpperCase() -> TokenType.TYPE
                        i < code.length && code[i] == '(' -> TokenType.FUNCTION
                        else -> TokenType.IDENTIFIER
                    }
                    tokens.add(Token(type, start, i, text))
                }
                
                code[i] in "+-*/%=<>!&|^~" -> {
                    val start = i
                    while (i < code.length && code[i] in "+-*/%=<>!&|^~") i++
                    tokens.add(Token(TokenType.OPERATOR, start, i, code.substring(start, i)))
                }
                
                else -> {
                    tokens.add(Token(TokenType.PUNCTUATION, i, i + 1, code[i].toString()))
                    i++
                }
            }
        }
        
        return tokens
    }
    
    private fun tokenizeXml(code: String): List<Token> {
        val tokens = mutableListOf<Token>()
        var i = 0
        
        while (i < code.length) {
            when {
                code[i].isWhitespace() -> i++
                
                code.startsWith("<!--", i) -> {
                    val start = i
                    i += 4
                    while (i < code.length - 2 && !code.startsWith("-->", i)) i++
                    if (i < code.length - 2) i += 3
                    tokens.add(Token(TokenType.COMMENT, start, i, code.substring(start, i)))
                }
                
                code[i] == '<' -> {
                    val start = i
                    i++
                    if (i < code.length && code[i] == '/') i++
                    
                    while (i < code.length && (code[i].isLetterOrDigit() || code[i] in ":-_")) i++
                    tokens.add(Token(TokenType.XML_TAG, start, i, code.substring(start, i)))
                    
                    while (i < code.length && code[i] != '>') {
                        if (code[i].isWhitespace()) {
                            i++
                        } else if (code[i].isLetter()) {
                            val attrStart = i
                            while (i < code.length && (code[i].isLetterOrDigit() || code[i] in ":-_")) i++
                            tokens.add(Token(TokenType.XML_ATTRIBUTE, attrStart, i, code.substring(attrStart, i)))
                        } else if (code[i] == '=') {
                            i++
                        } else if (code[i] == '"') {
                            val valueStart = i
                            i++
                            while (i < code.length && code[i] != '"') i++
                            if (i < code.length) i++
                            tokens.add(Token(TokenType.XML_VALUE, valueStart, i, code.substring(valueStart, i)))
                        } else {
                            i++
                        }
                    }
                    
                    if (i < code.length && code[i] == '>') {
                        tokens.add(Token(TokenType.PUNCTUATION, i, i + 1, ">"))
                        i++
                    }
                }
                
                else -> i++
            }
        }
        
        return tokens
    }
    
    private fun tokenizeJson(code: String): List<Token> {
        val tokens = mutableListOf<Token>()
        var i = 0
        
        while (i < code.length) {
            when {
                code[i].isWhitespace() -> i++
                
                code[i] == '"' -> {
                    val start = i
                    i++
                    while (i < code.length && (code[i] != '"' || code[i - 1] == '\\')) i++
                    if (i < code.length) i++
                    tokens.add(Token(TokenType.STRING, start, i, code.substring(start, i)))
                }
                
                code[i].isDigit() || code[i] == '-' -> {
                    val start = i
                    if (code[i] == '-') i++
                    while (i < code.length && (code[i].isDigit() || code[i] in ".eE+-")) i++
                    tokens.add(Token(TokenType.NUMBER, start, i, code.substring(start, i)))
                }
                
                code.startsWith("true", i) || code.startsWith("false", i) || 
                code.startsWith("null", i) -> {
                    val start = i
                    while (i < code.length && code[i].isLetter()) i++
                    tokens.add(Token(TokenType.KEYWORD, start, i, code.substring(start, i)))
                }
                
                else -> {
                    tokens.add(Token(TokenType.PUNCTUATION, i, i + 1, code[i].toString()))
                    i++
                }
            }
        }
        
        return tokens
    }
    
    fun getColorForToken(type: TokenType, isDark: Boolean = true): Color {
        return if (isDark) {
            when (type) {
                TokenType.KEYWORD -> Color(0xFFCC7832)
                TokenType.STRING -> Color(0xFF6A8759)
                TokenType.NUMBER -> Color(0xFF6897BB)
                TokenType.COMMENT -> Color(0xFF808080)
                TokenType.OPERATOR -> Color(0xFFA9B7C6)
                TokenType.TYPE -> Color(0xFF FFC66D)
                TokenType.FUNCTION -> Color(0xFFFFC66D)
                TokenType.ANNOTATION -> Color(0xFFBBB529)
                TokenType.XML_TAG -> Color(0xFFE8BF6A)
                TokenType.XML_ATTRIBUTE -> Color(0xFFBABDD6)
                TokenType.XML_VALUE -> Color(0xFFA5C261)
                else -> Color(0xFFA9B7C6)
            }
        } else {
            when (type) {
                TokenType.KEYWORD -> Color(0xFF000080)
                TokenType.STRING -> Color(0xFF008000)
                TokenType.NUMBER -> Color(0xFF0000FF)
                TokenType.COMMENT -> Color(0xFF808080)
                TokenType.OPERATOR -> Color(0xFF000000)
                TokenType.TYPE -> Color(0xFF000000)
                TokenType.FUNCTION -> Color(0xFF00627A)
                TokenType.ANNOTATION -> Color(0xFF808000)
                TokenType.XML_TAG -> Color(0xFF000080)
                TokenType.XML_ATTRIBUTE -> Color(0xFF0000FF)
                TokenType.XML_VALUE -> Color(0xFF008000)
                else -> Color(0xFF000000)
            }
        }
    }
}
