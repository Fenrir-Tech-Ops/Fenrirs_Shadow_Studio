package com.fenrirshadowstudio.witness

import java.io.File

data class CodeIssue(
    val severity: IssueSeverity,
    val type: IssueType,
    val message: String,
    val file: String,
    val line: Int,
    val column: Int,
    val suggestion: String? = null
)

enum class IssueSeverity {
    ERROR, WARNING, INFO, HINT
}

enum class IssueType {
    SYNTAX, LINT, PERFORMANCE, SECURITY, ACCESSIBILITY, STYLE
}

class Witness {
    fun analyzeKotlinFile(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        
        issues.addAll(checkUnusedImports(file, content))
        issues.addAll(checkNamingConventions(file, content))
        issues.addAll(checkHardcodedStrings(file, content))
        issues.addAll(checkPerformance(file, content))
        issues.addAll(checkSecurity(file, content))
        
        return issues
    }
    
    fun analyzeXmlFile(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        
        issues.addAll(checkAccessibility(file, content))
        issues.addAll(checkHardcodedDimensions(file, content))
        issues.addAll(checkMissingContentDescription(file, content))
        
        return issues
    }
    
    private fun checkUnusedImports(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        val lines = content.lines()
        
        val imports = mutableMapOf<String, Int>()
        lines.forEachIndexed { index, line ->
            if (line.trim().startsWith("import ")) {
                val importName = line.trim().substring(7).removeSuffix(";")
                imports[importName] = index + 1
            }
        }
        
        imports.forEach { (importName, lineNumber) ->
            val className = importName.substringAfterLast('.')
            val isUsed = content.contains(className)
            
            if (!isUsed) {
                issues.add(
                    CodeIssue(
                        severity = IssueSeverity.WARNING,
                        type = IssueType.LINT,
                        message = "Unused import: $importName",
                        file = file.absolutePath,
                        line = lineNumber,
                        column = 1,
                        suggestion = "Remove this import"
                    )
                )
            }
        }
        
        return issues
    }
    
    private fun checkNamingConventions(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        val lines = content.lines()
        
        lines.forEachIndexed { index, line ->
            val trimmed = line.trim()
            
            if (trimmed.startsWith("class ") || trimmed.startsWith("interface ") || 
                trimmed.startsWith("object ") || trimmed.startsWith("data class ")) {
                val className = trimmed.split(" ")[if (trimmed.startsWith("data")) 2 else 1]
                    .substringBefore("(").substringBefore("{").substringBefore(":")
                
                if (className.firstOrNull()?.isLowerCase() == true) {
                    issues.add(
                        CodeIssue(
                            severity = IssueSeverity.WARNING,
                            type = IssueType.STYLE,
                            message = "Class name '$className' should start with uppercase",
                            file = file.absolutePath,
                            line = index + 1,
                            column = 1
                        )
                    )
                }
            }
            
            if (trimmed.startsWith("fun ")) {
                val functionName = trimmed.substring(4).substringBefore("(").trim()
                
                if (functionName.firstOrNull()?.isUpperCase() == true) {
                    issues.add(
                        CodeIssue(
                            severity = IssueSeverity.WARNING,
                            type = IssueType.STYLE,
                            message = "Function name '$functionName' should start with lowercase",
                            file = file.absolutePath,
                            line = index + 1,
                            column = 1
                        )
                    )
                }
            }
        }
        
        return issues
    }
    
    private fun checkHardcodedStrings(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        val lines = content.lines()
        
        lines.forEachIndexed { index, line ->
            val regex = """"([^"]+)"""".toRegex()
            val matches = regex.findAll(line)
            
            matches.forEach { match ->
                val string = match.groupValues[1]
                if (string.length > 3 && !string.matches(Regex("[a-z_]+")) && 
                    !line.contains("import") && !line.contains("package")) {
                    issues.add(
                        CodeIssue(
                            severity = IssueSeverity.INFO,
                            type = IssueType.LINT,
                            message = "Hardcoded string: \"$string\"",
                            file = file.absolutePath,
                            line = index + 1,
                            column = line.indexOf(match.value) + 1,
                            suggestion = "Extract to strings.xml"
                        )
                    )
                }
            }
        }
        
        return issues
    }
    
    private fun checkPerformance(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        val lines = content.lines()
        
        lines.forEachIndexed { index, line ->
            if (line.contains("findViewById")) {
                issues.add(
                    CodeIssue(
                        severity = IssueSeverity.HINT,
                        type = IssueType.PERFORMANCE,
                        message = "Consider using View Binding instead of findViewById",
                        file = file.absolutePath,
                        line = index + 1,
                        column = line.indexOf("findViewById") + 1,
                        suggestion = "Use View Binding for better performance"
                    )
                )
            }
            
            if (line.contains("Log.d") || line.contains("Log.v") || line.contains("Log.i")) {
                issues.add(
                    CodeIssue(
                        severity = IssueSeverity.INFO,
                        type = IssueType.PERFORMANCE,
                        message = "Debug log statement found",
                        file = file.absolutePath,
                        line = index + 1,
                        column = 1,
                        suggestion = "Remove debug logs in production"
                    )
                )
            }
        }
        
        return issues
    }
    
    private fun checkSecurity(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        val lines = content.lines()
        
        lines.forEachIndexed { index, line ->
            if (line.contains("MODE_WORLD_READABLE") || line.contains("MODE_WORLD_WRITEABLE")) {
                issues.add(
                    CodeIssue(
                        severity = IssueSeverity.ERROR,
                        type = IssueType.SECURITY,
                        message = "Security risk: World-accessible file mode",
                        file = file.absolutePath,
                        line = index + 1,
                        column = 1,
                        suggestion = "Use MODE_PRIVATE instead"
                    )
                )
            }
            
            if (line.contains("addJavascriptInterface")) {
                issues.add(
                    CodeIssue(
                        severity = IssueSeverity.WARNING,
                        type = IssueType.SECURITY,
                        message = "Potential security risk with JavascriptInterface",
                        file = file.absolutePath,
                        line = index + 1,
                        column = 1,
                        suggestion = "Ensure @JavascriptInterface annotation is used and validate all inputs"
                    )
                )
            }
        }
        
        return issues
    }
    
    private fun checkAccessibility(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        val lines = content.lines()
        
        lines.forEachIndexed { index, line ->
            if ((line.contains("<ImageView") || line.contains("<ImageButton")) && 
                !content.contains("android:contentDescription")) {
                issues.add(
                    CodeIssue(
                        severity = IssueSeverity.WARNING,
                        type = IssueType.ACCESSIBILITY,
                        message = "Missing contentDescription for image",
                        file = file.absolutePath,
                        line = index + 1,
                        column = 1,
                        suggestion = "Add android:contentDescription for accessibility"
                    )
                )
            }
        }
        
        return issues
    }
    
    private fun checkHardcodedDimensions(file: File, content: String): List<CodeIssue> {
        val issues = mutableListOf<CodeIssue>()
        val lines = content.lines()
        
        val dimensionRegex = """"(\d+)(dp|sp)"""".toRegex()
        
        lines.forEachIndexed { index, line ->
            dimensionRegex.findAll(line).forEach { match ->
                issues.add(
                    CodeIssue(
                        severity = IssueSeverity.INFO,
                        type = IssueType.LINT,
                        message = "Hardcoded dimension: ${match.value}",
                        file = file.absolutePath,
                        line = index + 1,
                        column = line.indexOf(match.value) + 1,
                        suggestion = "Extract to dimens.xml"
                    )
                )
            }
        }
        
        return issues
    }
    
    private fun checkMissingContentDescription(file: File, content: String): List<CodeIssue> {
        return checkAccessibility(file, content)
    }
}
