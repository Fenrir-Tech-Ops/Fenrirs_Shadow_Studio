package com.fenrirshadowstudio.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun CodeEditor(
    initialContent: String = "",
    language: String = "kotlin",
    onContentChange: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var rope by remember { mutableStateOf(Rope.from(initialContent)) }
    var cursorPosition by remember { mutableStateOf(0) }
    var selectionStart by remember { mutableStateOf<Int?>(null) }
    var fontSize by remember { mutableStateOf(14.sp) }
    val verticalScrollState = rememberScrollState()
    val horizontalScrollState = rememberScrollState()
    val scope = rememberCoroutineScope()
    
    val tokens = remember(rope, language) {
        SyntaxHighlighter.tokenize(rope.toString(), language)
    }
    
    val annotatedText = remember(tokens) {
        buildAnnotatedString {
            var lastIndex = 0
            tokens.forEach { token ->
                if (token.start > lastIndex) {
                    append(rope.substring(lastIndex, token.start))
                }
                
                withStyle(
                    SpanStyle(
                        color = SyntaxHighlighter.getColorForToken(
                            token.type,
                            isDark = true
                        )
                    )
                ) {
                    append(token.text)
                }
                
                lastIndex = token.end
            }
            
            if (lastIndex < rope.length) {
                append(rope.substring(lastIndex, rope.length))
            }
        }
    }
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .pointerInput(Unit) {
                detectTransformGestures { _, _, zoom, _ ->
                    fontSize = (fontSize.value * zoom).coerceIn(8f, 32f).sp
                }
            }
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            LineNumberColumn(
                lineCount = rope.lineCount,
                fontSize = fontSize,
                modifier = Modifier
                    .verticalScroll(verticalScrollState)
                    .padding(end = 8.dp)
            )
            
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(verticalScrollState)
                    .horizontalScroll(horizontalScrollState)
                    .padding(4.dp)
            ) {
                SelectionContainer {
                    Text(
                        text = annotatedText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = fontSize,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .pointerInput(Unit) {
                                detectTapGestures { offset ->
                                    cursorPosition = calculateCursorPosition(offset, rope, fontSize.value)
                                }
                            }
                    )
                }
            }
        }
    }
}

@Composable
private fun LineNumberColumn(
    lineCount: Int,
    fontSize: androidx.compose.ui.unit.TextUnit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            .padding(horizontal = 8.dp)
    ) {
        repeat(lineCount) { line ->
            Text(
                text = (line + 1).toString(),
                fontFamily = FontFamily.Monospace,
                fontSize = fontSize,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                modifier = Modifier.padding(vertical = 2.dp)
            )
        }
    }
}

private fun calculateCursorPosition(
    offset: Offset,
    rope: Rope,
    fontSize: Float
): Int {
    val lineHeight = fontSize * 1.5f
    val charWidth = fontSize * 0.6f
    
    val line = (offset.y / lineHeight).toInt().coerceIn(0, rope.lineCount - 1)
    val column = (offset.x / charWidth).toInt().coerceAtLeast(0)
    
    val lineStart = rope.lineStart(line)
    val lineText = rope.lineAt(line)
    val lineEnd = lineStart + lineText.length
    
    return (lineStart + column).coerceIn(lineStart, lineEnd)
}

data class EditorState(
    val content: Rope = Rope.empty(),
    val cursorPosition: Int = 0,
    val selectionStart: Int? = null,
    val language: String = "kotlin",
    val isDirty: Boolean = false,
    val filePath: String? = null
)

class EditorViewModel {
    private val _state = mutableStateOf(EditorState())
    val state: State<EditorState> = _state
    
    private val undoStack = mutableListOf<Rope>()
    private val redoStack = mutableListOf<Rope>()
    
    fun loadFile(content: String, filePath: String, language: String = "kotlin") {
        undoStack.clear()
        redoStack.clear()
        _state.value = EditorState(
            content = Rope.from(content),
            filePath = filePath,
            language = language,
            isDirty = false
        )
    }
    
    fun insertText(text: String, position: Int) {
        undoStack.add(_state.value.content)
        redoStack.clear()
        
        val newContent = _state.value.content.insert(position, text)
        _state.value = _state.value.copy(
            content = newContent,
            cursorPosition = position + text.length,
            isDirty = true
        )
    }
    
    fun deleteText(start: Int, end: Int) {
        if (start >= end) return
        
        undoStack.add(_state.value.content)
        redoStack.clear()
        
        val newContent = _state.value.content.delete(start, end)
        _state.value = _state.value.copy(
            content = newContent,
            cursorPosition = start,
            isDirty = true
        )
    }
    
    fun undo() {
        if (undoStack.isNotEmpty()) {
            redoStack.add(_state.value.content)
            val previousContent = undoStack.removeAt(undoStack.lastIndex)
            _state.value = _state.value.copy(content = previousContent, isDirty = true)
        }
    }
    
    fun redo() {
        if (redoStack.isNotEmpty()) {
            undoStack.add(_state.value.content)
            val nextContent = redoStack.removeAt(redoStack.lastIndex)
            _state.value = _state.value.copy(content = nextContent, isDirty = true)
        }
    }
    
    fun save(): String {
        _state.value = _state.value.copy(isDirty = false)
        return _state.value.content.toString()
    }
    
    fun setCursor(position: Int) {
        _state.value = _state.value.copy(cursorPosition = position)
    }
    
    fun setSelection(start: Int, end: Int) {
        _state.value = _state.value.copy(
            selectionStart = start,
            cursorPosition = end
        )
    }
}
