package com.fenrirshadowstudio.project

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

sealed class FileNode {
    abstract val path: String
    abstract val name: String
    
    data class Directory(
        override val path: String,
        override val name: String,
        val children: MutableList<FileNode> = mutableListOf(),
        var isExpanded: Boolean = false
    ) : FileNode()
    
    data class FileItem(
        override val path: String,
        override val name: String,
        val extension: String
    ) : FileNode()
}

@Composable
fun ProjectPane(
    projectRoot: File?,
    onFileSelected: (File) -> Unit,
    onFileCreated: (File, String) -> Unit,
    onFolderCreated: (File, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var fileTree by remember(projectRoot) {
        mutableStateOf(projectRoot?.let { buildFileTree(it) })
    }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var selectedNode by remember { mutableStateOf<FileNode?>(null) }
    
    Column(modifier = modifier.fillMaxSize()) {
        ProjectToolbar(
            onNewFile = { showNewFileDialog = true },
            onNewFolder = { showNewFolderDialog = true },
            onRefresh = { fileTree = projectRoot?.let { buildFileTree(it) } }
        )
        
        if (fileTree != null && projectRoot != null) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(8.dp)
            ) {
                items(flattenTree(fileTree!!)) { node ->
                    FileTreeItem(
                        node = node,
                        depth = calculateDepth(node, fileTree!!),
                        isSelected = selectedNode == node,
                        onClick = {
                            selectedNode = node
                            when (node) {
                                is FileNode.Directory -> {
                                    node.isExpanded = !node.isExpanded
                                    fileTree = fileTree
                                }
                                is FileNode.FileItem -> {
                                    onFileSelected(File(node.path))
                                }
                            }
                        }
                    )
                }
            }
        } else {
            EmptyProjectView(
                onOpenProject = { },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
    
    if (showNewFileDialog) {
        CreateFileDialog(
            onDismiss = { showNewFileDialog = false },
            onCreate = { fileName ->
                projectRoot?.let { root ->
                    val newFile = File(root, fileName)
                    onFileCreated(newFile, "")
                    fileTree = buildFileTree(root)
                }
                showNewFileDialog = false
            }
        )
    }
    
    if (showNewFolderDialog) {
        CreateFolderDialog(
            onDismiss = { showNewFolderDialog = false },
            onCreate = { folderName ->
                projectRoot?.let { root ->
                    val newFolder = File(root, folderName)
                    onFolderCreated(newFolder, "")
                    fileTree = buildFileTree(root)
                }
                showNewFolderDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProjectToolbar(
    onNewFile: () -> Unit,
    onNewFolder: () -> Unit,
    onRefresh: () -> Unit
) {
    TopAppBar(
        title = { Text("Project") },
        actions = {
            IconButton(onClick = onNewFile) {
                Icon(Icons.Default.Add, "New File")
            }
            IconButton(onClick = onNewFolder) {
                Icon(Icons.Default.CreateNewFolder, "New Folder")
            }
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, "Refresh")
            }
        }
    )
}

@Composable
private fun FileTreeItem(
    node: FileNode,
    depth: Int,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        color = if (isSelected) {
            MaterialTheme.colorScheme.secondaryContainer
        } else {
            MaterialTheme.colorScheme.surface
        }
    ) {
        Row(
            modifier = Modifier
                .padding(
                    start = (16 * depth).dp,
                    top = 4.dp,
                    bottom = 4.dp,
                    end = 8.dp
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = when (node) {
                    is FileNode.Directory -> {
                        if (node.isExpanded) Icons.Default.KeyboardArrowDown
                        else Icons.Default.KeyboardArrowRight
                    }
                    is FileNode.FileItem -> getFileIcon(node.extension)
                },
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = when (node) {
                    is FileNode.Directory -> MaterialTheme.colorScheme.primary
                    is FileNode.FileItem -> getFileIconColor(node.extension)
                }
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = node.name,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isSelected) {
                    MaterialTheme.colorScheme.onSecondaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurface
                }
            )
        }
    }
}

@Composable
private fun EmptyProjectView(
    onOpenProject: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.FolderOpen,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
            )
            
            Text(
                text = "No project loaded",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            
            Button(onClick = onOpenProject) {
                Text("Open Project")
            }
        }
    }
}

@Composable
private fun CreateFileDialog(
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    var fileName by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New File") },
        text = {
            TextField(
                value = fileName,
                onValueChange = { fileName = it },
                label = { Text("File name") },
                placeholder = { Text("MainActivity.kt") },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onCreate(fileName) },
                enabled = fileName.isNotBlank()
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun CreateFolderDialog(
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    var folderName by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Folder") },
        text = {
            TextField(
                value = folderName,
                onValueChange = { folderName = it },
                label = { Text("Folder name") },
                placeholder = { Text("utils") },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onCreate(folderName) },
                enabled = folderName.isNotBlank()
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

private fun buildFileTree(root: File): FileNode.Directory {
    val rootNode = FileNode.Directory(
        path = root.absolutePath,
        name = root.name,
        isExpanded = true
    )
    
    fun addChildren(parent: FileNode.Directory, dir: File) {
        dir.listFiles()?.sortedWith(
            compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() }
        )?.forEach { file ->
            if (file.isDirectory) {
                val dirNode = FileNode.Directory(
                    path = file.absolutePath,
                    name = file.name
                )
                parent.children.add(dirNode)
                addChildren(dirNode, file)
            } else {
                parent.children.add(
                    FileNode.FileItem(
                        path = file.absolutePath,
                        name = file.name,
                        extension = file.extension
                    )
                )
            }
        }
    }
    
    addChildren(rootNode, root)
    return rootNode
}

private fun flattenTree(root: FileNode.Directory): List<FileNode> {
    val result = mutableListOf<FileNode>()
    
    fun flatten(node: FileNode) {
        result.add(node)
        if (node is FileNode.Directory && node.isExpanded) {
            node.children.forEach { flatten(it) }
        }
    }
    
    flatten(root)
    return result
}

private fun calculateDepth(node: FileNode, root: FileNode.Directory): Int {
    var depth = 0
    var current = node.path
    val rootPath = root.path
    
    while (current != rootPath && current.contains(File.separator)) {
        current = File(current).parent ?: break
        if (current.startsWith(rootPath)) depth++
    }
    
    return depth
}

@Composable
private fun getFileIcon(extension: String) = when (extension.lowercase()) {
    "kt" -> Icons.Default.Code
    "java" -> Icons.Default.Code
    "xml" -> Icons.Default.Code
    "json" -> Icons.Default.DataObject
    "gradle", "kts" -> Icons.Default.Build
    "png", "jpg", "jpeg", "gif", "webp" -> Icons.Default.Image
    else -> Icons.Default.InsertDriveFile
}

@Composable
private fun getFileIconColor(extension: String) = when (extension.lowercase()) {
    "kt" -> MaterialTheme.colorScheme.primary
    "java" -> MaterialTheme.colorScheme.tertiary
    "xml" -> MaterialTheme.colorScheme.secondary
    "json" -> MaterialTheme.colorScheme.tertiary
    else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
}
